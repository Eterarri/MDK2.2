﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX3._28
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите числа A,B,C");

            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());
            double c = double.Parse(Console.ReadLine());
            if (a>100 && b>100)
            {
                Console.WriteLine("Числа а и b больше 100");
            }
            if (a % 2 == 0 || b % 2 == 0 )
            {
                Console.WriteLine("Одно из чисел а и b чётное");
            }
            if (a>0 || b>0)
            {
                Console.WriteLine("Одно из чисел а и b положительно");
            }
            if (a % 3 == 0 && b % 3 == 0 && c % 3 == 0)
            {
                Console.WriteLine("Каждое число кратно 3");
            }
            if (a<50 || b<50 || c<50)
            {
                Console.WriteLine("Только одно из чисел меньше 50");
            }
            if (a<0 || b<0 || c<0)
            {
                Console.WriteLine("Одно из чисел отрицательно");
            }
        }
    }
}
