﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX2._40
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите время: часы и минуты");
            double chas = double.Parse(Console.ReadLine());
            double min = double.Parse(Console.ReadLine());
            Console.WriteLine($"Градус = {chas * 30 + min / 2}");
            Console.ReadKey();
        }
    }
}
