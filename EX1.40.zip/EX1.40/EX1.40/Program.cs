﻿using System;
namespace EX1._40
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите а и b");
            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());
            double resulx = (2d / (Math.Pow(a, 2) + 25d)) + b;
            double resulx1 = Math.Sqrt(b) + ((a + b) / 2d);
            Console.WriteLine(resulx / resulx1);
            Console.ReadKey();
        }
    }
}
